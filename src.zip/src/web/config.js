const config = {
  apiUrl: 'http://localhost:3000'
};

export default config;